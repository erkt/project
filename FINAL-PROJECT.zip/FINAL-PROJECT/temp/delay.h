//delay.h
void DelayMS(unsigned  int dly){
	unsigned char j;
	for( dly;dly>0;dly--){
			for(j=250;j>0;j--);
			for(j=247;j>0;j--);
	}
}